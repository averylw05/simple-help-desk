const API_URL = "http://localhost:8080/api/tickets";

const ticketForm = document.getElementById("ticketForm");
const nameInput = document.getElementById("nameInput");
const emailInput = document.getElementById("emailInput");
const titleInput = document.getElementById("titleInput");
const descriptionInput = document.getElementById("descriptionInput");

const ticketList = document.getElementById("ticketList");
const emptyState = document.getElementById("emptyState");
const ticketCount = document.getElementById("ticketCount");
const filterInput = document.getElementById("filterInput");

const apiStatusDot = document.getElementById("apiStatusDot");
const apiStatusText = document.getElementById("apiStatusText");

let tickets = [];

ticketForm.addEventListener("submit", createTicket);
filterInput.addEventListener("change", renderTickets);

loadTickets();

async function loadTickets() {
  try {
    const response = await fetch(API_URL);

    if (!response.ok) {
      throw new Error("API request failed");
    }

    tickets = await response.json();
    setApiStatus(true);
    renderTickets();
  } catch (error) {
    setApiStatus(false);
    console.error(error);
  }
}

async function createTicket(event) {
  event.preventDefault();

  const ticket = {
    requesterName: nameInput.value.trim(),
    requesterEmail: emailInput.value.trim(),
    title: titleInput.value.trim(),
    description: descriptionInput.value.trim()
  };

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(ticket)
    });

    if (!response.ok) {
      throw new Error("Could not create ticket");
    }

    ticketForm.reset();
    await loadTickets();
  } catch (error) {
    alert("Ticket was not created. Make sure the Spring Boot backend is running.");
    console.error(error);
  }
}

async function updateStatus(id, status) {
  try {
    const response = await fetch(`${API_URL}/${id}/status`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ status })
    });

    if (!response.ok) {
      throw new Error("Could not update ticket");
    }

    await loadTickets();
  } catch (error) {
    alert("Ticket was not updated. Make sure the backend is running.");
    console.error(error);
  }
}

async function deleteTicket(id) {
  const confirmed = confirm("Delete this ticket?");

  if (!confirmed) {
    return;
  }

  try {
    const response = await fetch(`${API_URL}/${id}`, {
      method: "DELETE"
    });

    if (!response.ok) {
      throw new Error("Could not delete ticket");
    }

    await loadTickets();
  } catch (error) {
    alert("Ticket was not deleted. Make sure the backend is running.");
    console.error(error);
  }
}

function renderTickets() {
  const selectedFilter = filterInput.value;

  const filteredTickets = tickets.filter((ticket) => {
    return selectedFilter === "ALL" || ticket.status === selectedFilter;
  });

  ticketList.innerHTML = "";

  if (filteredTickets.length === 0) {
    emptyState.classList.remove("hidden");
  } else {
    emptyState.classList.add("hidden");
  }

  ticketCount.textContent = `${filteredTickets.length} ticket${filteredTickets.length === 1 ? "" : "s"}`;

  filteredTickets.forEach((ticket) => {
    const card = document.createElement("article");
    card.className = "ticket-card";

    card.innerHTML = `
      <div class="ticket-top">
        <div>
          <h3 class="ticket-title">${escapeHTML(ticket.title)}</h3>
          <p class="ticket-meta">
            ${escapeHTML(ticket.requesterName)} • ${escapeHTML(ticket.requesterEmail)}
          </p>
        </div>
        <span class="badge ${ticket.status}">${formatStatus(ticket.status)}</span>
      </div>

      <p class="ticket-description">${escapeHTML(ticket.description)}</p>

      <p class="ticket-meta">Created: ${formatDate(ticket.createdAt)}</p>

      <div class="ticket-actions">
        <button type="button" onclick="updateStatus(${ticket.id}, 'OPEN')">Mark Open</button>
        <button type="button" onclick="updateStatus(${ticket.id}, 'IN_PROGRESS')">Mark In Progress</button>
        <button type="button" onclick="updateStatus(${ticket.id}, 'CLOSED')">Mark Closed</button>
        <button type="button" class="delete-button" onclick="deleteTicket(${ticket.id})">Delete</button>
      </div>
    `;

    ticketList.appendChild(card);
  });
}

function setApiStatus(isOnline) {
  if (isOnline) {
    apiStatusDot.className = "status-dot online";
    apiStatusText.textContent = "Backend Online";
  } else {
    apiStatusDot.className = "status-dot offline";
    apiStatusText.textContent = "Backend Offline";
  }
}

function formatStatus(status) {
  if (status === "IN_PROGRESS") {
    return "IN PROGRESS";
  }

  return status;
}

function formatDate(value) {
  if (!value) {
    return "Unknown";
  }

  return new Date(value).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit"
  });
}

function escapeHTML(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}
