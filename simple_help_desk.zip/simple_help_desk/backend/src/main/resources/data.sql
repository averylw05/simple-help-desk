INSERT INTO ticket (requester_name, requester_email, title, description, status, created_at)
VALUES
('Avery Wirthlin', 'averywirthlin60@gmail.com', 'Laptop cannot connect to Wi-Fi', 'The laptop shows available networks but fails when trying to connect.', 'OPEN', CURRENT_TIMESTAMP),
('Jordan Smith', 'jordan@example.com', 'Password reset needed', 'User is locked out and needs help resetting their password.', 'IN_PROGRESS', CURRENT_TIMESTAMP),
('Taylor Lee', 'taylor@example.com', 'Printer not responding', 'Office printer is online but print jobs stay stuck in queue.', 'CLOSED', CURRENT_TIMESTAMP);
