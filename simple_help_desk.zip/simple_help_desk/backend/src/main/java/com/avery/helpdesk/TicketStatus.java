package com.avery.helpdesk;

public enum TicketStatus {
    OPEN,
    IN_PROGRESS,
    CLOSED
}
